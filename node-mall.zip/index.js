require('babel-register');
require('./app.js')