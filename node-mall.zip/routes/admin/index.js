import login from '../../controller/login'
export default function(app) {
    new login(app)
}